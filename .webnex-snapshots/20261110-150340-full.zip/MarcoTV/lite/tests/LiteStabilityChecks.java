// Copyright (C) 2026 Pilipala
// SPDX-License-Identifier: GPL-3.0-only
package com.pilipala.tvhome;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import java.util.*;
import java.io.*;
import java.lang.reflect.*;
public final class LiteStabilityChecks extends Instrumentation {
    LiteActivity host;
    SharedPreferences original;
    Map<String,?> before;
    byte[] oldBackup;
    boolean backupExisted;
    TimeZone timezone;
    int observations,passes;
    void emit(String kind,String name,boolean condition){
        if(!condition)throw new AssertionError(kind+" "+name);
        if(kind.equals("OBSERVED"))observations++;
        else passes++;
        Bundle b=new Bundle();
        b.putString("stream",kind+" "+name+"\n");
        sendStatus(0,b);
    }
    void key(int code){
        long t=SystemClock.uptimeMillis();
        host.home.dispatchKeyEvent(new KeyEvent(t,t,0,code,0));
        host.home.dispatchKeyEvent(new KeyEvent(t,t+1,1,code,0));
    }
    int hash(ClockScene clock){
        Bitmap b=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);
        clock.draw(new Canvas(b),original,0);
        int[] pixels=new int[1920*1080];
        b.getPixels(pixels,0,1920,0,0,1920,1080);
        b.recycle();
        return Arrays.hashCode(pixels);
    }
    void ui(final Runnable action){
        final Throwable[] error={null};
        runOnMainSync(new Runnable(){
            public void run(){
                try{
                    action.run();
                }catch(Throwable t){
                    error[0]=t;
                }
            }
        });
        if(error[0]!=null)throw new AssertionError(error[0]);
    }
    byte[] read(File file)throws Exception{
        FileInputStream in=new FileInputStream(file);
        try{
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] buffer=new byte[4096];
            int n;
            while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            return out.toByteArray();
        }finally{
            in.close();
        }
    }
    public void onCreate(Bundle args){
        super.onCreate(args);
        start();
    }
    public void onStart(){
        Bundle result=new Bundle();
        try{
            host=(LiteActivity)startActivitySync(new Intent().setClassName("com.pilipala.tvhome.lite","com.pilipala.tvhome.LiteActivity")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            original=host.prefs;
            before=new HashMap<String,Object>(original.getAll());
            timezone=TimeZone.getDefault();
            File backup=new File(host.getFilesDir(),"lite-backup.json");
            backupExisted=backup.exists();
            if(backupExisted)oldBackup=read(backup);
            Thread.sleep(2500);
            ui(new Runnable(){
                public void run(){
                    host.home.saver.snap(0);
                    host.home.ambientAmount=0;
                    host.home.closePage();
                    host.home.wake();
                    host.home.open(1);
                    host.home.choice=4;
                    host.onPause();
                    host.onResume();
                    emit("PASS","pause_resume_preserves_system_settings_return_location",host.home.page==1&&host.home.choice==4);
                    host.home.closePage();
                    host.home.open(2);
                    host.home.choice=1;
                    int old=original.getInt("card_height",100);
                    host.home.change(old==130?-1:1);
                    host.onPause();
                    host.onResume();
                    emit("PASS","temporary_pause_keeps_unsaved_magic_draft",host.home.page==2&&host.home.draft!=null&&host.home.draft.getInt("card_height",
                            100)!=old&&original.getInt("card_height",100)==old);
                    Bundle saved=new Bundle();
                    host.onSaveInstanceState(saved);
                    host.home.closePage();
                    host.home.restoreState(saved);
                    emit("PASS","saved_instance_state_restores_draft",host.home.page==2&&host.home.choice==1&&host.home.draft.getInt("card_height",
                            100)!=old);
                    host.onNewIntent(new Intent());
                    emit("PASS","home_still_discards_preserved_draft",host.home.page==0&&host.home.draft==null);
                    TimeZone.setDefault(TimeZone.getTimeZone("GMT+00:00"));
                    ClockScene c=new ClockScene(host);
                    int first=hash(c);
                    TimeZone.setDefault(TimeZone.getTimeZone("GMT+08:00"));
                    int after=hash(c),fresh=hash(new ClockScene(host));
                    emit("PASS","existing_clock_follows_new_timezone",first!=after&&fresh==after);
                    TimeZone.setDefault(timezone);
                    original.edit().putInt("card_height",125).commit();
                    host.backup(false);
                    original.edit().putInt("card_height",70).commit();
                    final int[] commits={0};
                    final SharedPreferences.Editor failed=(SharedPreferences.Editor)Proxy.newProxyInstance(getClass()
                            .getClassLoader(),new Class[]{SharedPreferences.Editor.class},new InvocationHandler(){
                        public Object invoke(Object proxy,Method method,Object[] args){
                            if(method.getName().equals("commit")){
                                commits[0]++;
                                return false;
                            }
                            if(method.getName().equals("apply"))return null;
                            return proxy;
                        }
                    });
                    host.prefs=(SharedPreferences)Proxy.newProxyInstance(getClass().getClassLoader(),new Class[]{SharedPreferences.class},new InvocationHandler(){
                        public Object invoke(Object proxy,Method method,Object[] args)throws Throwable{
                            if(method.getName().equals("edit"))return failed;
                            return method.invoke(original,args);
                        }
                    });
                    Bitmap oldWallpaper=host.home.wallpaper;
                    host.backup(true);
                    emit("PASS","failed_restore_commit_reports_failure",commits[0]==2&&original.getInt("card_height",0)==70&&host.home.wallpaper==oldWallpaper&&host.restoreStatus.equals("write_failed"));
                    host.prefs=original;
                    original.edit().putInt("motion",0).commit();
                    host.home.closePage();
                    host.home.topFocus=false;
                    for(int i=0;i<200;i++){
                        key(22);
                        key(21);
                        key(19);
                        key(20);
                    }
                    emit("PASS","800_dispatched_direction_events_keep_valid_selection",host.home.selected>=0&&host.home.selected<host.apps.size()&&host.home.page==0);
                    for(int i=0;i<100;i++){
                        host.home.open(1);
                        host.home.choice=7;
                        host.home.activate();
                        key(4);
                        if(host.home.choice!=7||host.home.page!=1)throw new AssertionError("back lost focus");
                        key(4);
                    }
                    emit("PASS","100_nested_navigation_cycles_restore_focus",host.home.page==0&&host.home.history.isEmpty());
                    for(int i=0;i<50;i++){
                        host.home.ambient=true;
                        host.home.saver.snap(1);
                        host.home.ambientAmount=1;
                        key(23);
                        if(host.home.page!=0||host.home.ambient)throw new AssertionError("wake activated");
                    }
                    emit("PASS","50_wake_confirm_cycles_do_not_activate_app",host.home.page==0);
                    for(int[] size:new int[][]{{960,540},{1280,720},{1920,1080}}){
                        Bitmap b=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);
                        host.home.layout(0,0,size[0],size[1]);
                        host.home.open(2);
                        host.home.draw(new Canvas(b));
                        host.home.closePage();
                        b.recycle();
                    }
                    emit("PASS","three_view_sizes_render_without_exception",true);
                }
            });
            result.putString("stream","OK 10 Lite stability checks\n");
        }catch(Throwable t){
            result.putString("stream","FAIL "+t+"\n");
        }finally{
            if(timezone!=null)TimeZone.setDefault(timezone);
            if(host!=null&&original!=null&&before!=null)ui(new Runnable(){
                public void run(){
                    host.prefs=original;
                    host.home.pause();
                    SharedPreferences.Editor e=original.edit().clear();
                    for(Map.Entry<String,?> x:before.entrySet()){
                        Object v=x.getValue();
                        if(v instanceof Integer)e.putInt(x.getKey(),(Integer)v);
                        else if(v instanceof Long)e.putLong(x.getKey(),(Long)v);
                        else if(v instanceof Boolean)e.putBoolean(x.getKey(),(Boolean)v);
                        else if(v instanceof String)e.putString(x.getKey(),(String)v);
                    }
                    e.commit();
                    try{
                        File f=new File(host.getFilesDir(),"lite-backup.json");
                        if(backupExisted){
                            FileOutputStream out=new FileOutputStream(f);
                            out.write(oldBackup);
                            out.close();
                        }else f.delete();
                    }catch(Exception ex){
                        throw new RuntimeException(ex);
                    }
                }
            });
        }
        finish(-1,result);
    }
}
