// Copyright (C) 2026 Pilipala · SPDX-License-Identifier: GPL-3.0-only
'use strict';
const $=id=>document.getElementById(id);
const base='https://marcotv.wlj9919.top/';
const brandText={generic:'在电视“关于 / 设备信息”核对系统和完整型号。标准 Android TV 可在关于页连续选择版本号，再返回开发者选项。USB 调试不等于网络调试。',xiaomi:'小米国内部分旧版：设置 → 账户与安全 → 允许 ADB 调试。网络详情可查看 IP。本项目实测仅 MiTV-ASTP0 / Android 9，不能套用于所有新固件。',google:'Android TV / Google TV：设置 → 系统 / 设备偏好设置 → 关于 → 连续选择 Build / 版本号，再进入开发者选项。以电视实际提供的网络调试为准；仅配对码机型暂不支持助手。',custom:'国内 TCL、雷鸟、海信、创维等入口因型号和固件变化。先记录完整型号、系统号，在本机帮助或厂商说明中核对安装与调试入口，不使用未经核实的工程菜单代码。',fire:'仅 Fire OS 机型：设置 → My Fire TV / Device & Software → About，连续选择设备名显示开发者选项，查找 ADB Debugging。不是所有 Fire TV 都运行 Fire OS；本项目未实测其 Home 接管。'};
Object.assign(brandText,{
 tcl:'国内部分 TCL／雷鸟：设置 → 系统 → 系统信息／本机信息，在该页依次按上、下、左、右，查看是否出现 ADB 开关。社区入口参考，尚未核实你的型号与固件；海外 Google TV 使用标准开发者入口。',
 skyworth:'部分创维／酷开：设置 → 关于本机 → 本机信息 → 更多信息，依次按上、上、下、下、左、右、左、右，查看通用设置中的 ADB 项。社区入口参考，当前固件可能不同，只查看调试项，其他工程参数保持原值。',
 hisense:'国内海信／Vidda 与海外 Google TV、VIDAA 不能共用一套方法。先核对完整型号、软件号与系统，在实际提供的开发者选项中查看调试。未确认时不要修改工厂参数或清空电视。',
 huawei:'华为／荣耀先确认具体型号是否兼容 Android APK。支持第三方安装不代表开放 ADB 或默认桌面。没有调试入口时不要仅凭 HarmonyOS 版本套用 Android 指令。'
});
function installationIssue(kind){
 const messages={
  source:'安装来源未允许：在电视系统中仅允许实际打开 APK 的浏览器或文件管理器安装未知应用，再重新打开安装包。与开启 ADB 是两回事。',
  verification:'INSTALL_FAILED_VERIFICATION_FAILURE：系统安装校验拒绝。先核对官方来源、完整下载和本机允许的安装入口；这不等于桌面签名限制，不默认关闭全局安装校验。',
  launcher:'提示 disable install launcher app not signature by tcl：这是厂商对桌面身份的安装限制。可查看项目受限兼容版的说明；该版本采用 Home 兼容，不能承诺原生默认桌面或该固件已适配。',
  signature:'仅提示签名不一致、没有 TCL 桌面限制文字：可能是已安装同包名但签名不同的应用。先核对来源和已有版本，保留配置；不要直接卸载，或把所有签名冲突都当作 TCL 限制。',
  connect:'无法连接／unauthorized：先检查电视是否提供普通网络调试、地址与端口是否正确，再在电视确认授权。USB 调试开关不保证网络端口开放，配对码端口也不能当作普通连接端口。'
 };
 return messages[kind]||'请选择电视上实际看到的提示，再按对应步骤检查。';
}
function route(system,device,entry){
 if(system==='other')return {title:'这台系统不能直接安装此 APK',intro:'Marco TV 是 Android 电视桌面，当前没有 Tizen、webOS、Roku 或 tvOS 版本。',steps:['不要下载安卓安装助手尝试强行安装。','如果电视连接了 Android 盒子，请按盒子的系统重新选择；安装目标是盒子。'],limit:'不会因为同一个电视品牌就自动获得 APK 兼容性。'};
 if(system==='unknown')return {title:'先确认系统，再决定安装路线',intro:'仅凭品牌或屏幕尺寸还不能判断。',steps:['打开原厂设置 → 关于 / 系统信息，记录完整型号与系统版本。','查对应型号官方说明，确认支持 Android APK，且 Android 版本不低于 6.0。','确认后回到上方选择 Android；不需要公开序列号、MAC 或家庭 IP。'],limit:'华为、荣耀与 VIDAA 等不能统一视为 Android 兼容系统。'};
 if(entry==='browser')return {title:'直接在电视浏览器下载',intro:'这条路线不需要手机助手，也不需要 ADB。',steps:['在电视浏览器输入 marcotv.wlj9919.top，下载“电视安装包”。','打开浏览器下载记录中的 APK，按系统提示允许这个浏览器安装未知应用。','选择安装，再从应用列表打开 Marco TV。'],download:'tv',limit:'手机上点击下载只会存到手机，不会自动发送给电视。电视浏览器如果无法打开 APK，请换另一条路线。'};
 if(entry==='receive')return {title:'用电视已有的接收入口',intro:'优先复用厂商提供的功能。不同电视的入口和支持文件类型不同。',steps:['在电视打开厂商的远程安装 / 文件接收功能，按屏幕说明连接手机或电脑。','下载下方“电视安装包”，通过该入口上传；不要选择安卓手机助手包。','在电视确认安装并按提示开放来源权限，再打开 Marco TV。'],download:'tv',limit:'只有照片投屏、视频投屏不等于支持传送或安装 APK。此页面不会扫描或连接你的电视。'};
 if(entry==='pair')return {title:'这台电视需要无线配对',intro:'当前 1.0.0 助手支持普通网络 ADB，尚未实现配对码连接。',steps:['不要把配对端口填进普通连接端口，也不要假设固定为 5555。','优先检查电视能否通过浏览器或厂商接收入口安装。','有电脑时，可按完整安装说明使用官方 ADB 配对流程；没有电脑且没有其他入口，当前无法完成首次安装。'],limit:'新版 Android 的无线配对端口和连接端口可能不同。',docs:true};
 if(entry==='none')return {title:'目前还缺一个电视安装入口',intro:'只有手机网页无法直接把 APK 装进尚未开放安装或调试的电视。',steps:['查厂商对应型号说明，确认是否提供下载、文件接收或网络调试。','若没有这些入口，需要借用 U 盘，或使用厂商明确支持的其他安装方式。','不建议为了安装桌面刷机、降级或删除原厂应用。'],limit:'不能靠开启手机端权限绕过电视的安装限制。'};
 if(device==='windows'||device==='android')return {title:device==='windows'?'用 Windows 助手安装':'用安卓手机助手安装',intro:entry==='unknown'?'先按下方品牌提示找到普通网络调试入口。能开启后，再使用助手。':'电视和安装设备保持在同一家庭网络，准备好遥控器。',steps:[device==='windows'?'下载 Windows 助手，在 Windows 10 / 11 双击运行；不需要安装 Python、Java 或 ADB。':'将“安卓手机助手”安装到 Android 8 及以上的手机上。手机提示时，仅允许实际下载它的浏览器安装未知应用。','在电视开启普通网络调试，查看电视 IP 和连接端口。助手可查找常见 5555 端口，找不到就手动填写。','点击连接，在电视弹窗选择允许。回到助手核对电视品牌型号。','点击安装并确认目标电视。助手校验内置正式包后传送，成功后点击打开桌面。'],download:device,limit:'目标电视至少 Android 6.0。当前仅普通网络 ADB；首次安装仍需电视允许连接。Windows 程序暂未配置商业代码签名；遇到系统拦截请先核对来源或使用其他路线，不关闭系统防护。'};
 return {title:device==='iphone'?'iPhone 优先使用电视自带入口':'先选择电视可用的安装入口',intro:'当前没有 iOS 或 macOS 版安装助手。',steps:['检查电视是否有能下载 APK 的浏览器，或厂商文件接收入口。','如果有，请在上方改选对应入口，按流程操作。','如果只有普通网络调试，可借用 Windows 电脑或安卓手机完成第一次安装。'],limit:'安装后可用 iPhone 浏览器进入 Marco TV 的Marco 互联；但它不能替代第一次安装。'};
}
function homeRoute(system){
 if(system!=='android')return route(system,'other','unknown');
 return {title:'先在电视里完成桌面选择',intro:'新版流程会优先打开电视已有的系统设置。仅使用默认桌面选择时，不需要电脑授权。',steps:['更新到 0.15.0 后，打开 Marco TV → 设置 → 系统与启动 → 桌面启用与检查，选择「开始设置」。当前版本未看到入口，请查看下方完整说明。','如果系统弹出桌面选择，选中 Marco TV。若没有此入口，按向导尝试「Home 兼容」，在辅助功能中仅开启 Marco TV。','打开另一个应用，按一次 Home 检查是否回到 Marco TV。再在方便时真正重启电视，查看开机是否返回；开关屏不算重启。','如果系统限制了这些操作，进入「更多设置方式」。本机自动设置需要普通网络调试与电视确认；新版可按本机指引进入系统设置，返回后自动继续一次。仅有无线配对码时查看助手说明。'],limit:'此网页只提供步骤，不远程修改电视。安装助手 1.0.0 只负责安装，不自动授权或选择桌面；默认桌面设置不需要付费。新流程已随 0.15.0 发布，其他机型仍待实测反馈。',docs:true};
}
function render(){const r=$('purpose').value==='home'?homeRoute($('system').value):route($('system').value,$('device').value,$('entry').value);$('routeTitle').textContent=r.title;$('routeIntro').textContent=r.intro;$('steps').replaceChildren(...r.steps.map(t=>{const li=document.createElement('li');li.textContent=t;return li;}));$('limits').textContent=r.limit;$('brandGuide').textContent=brandText[$('brand').value];$('download').replaceChildren();
 if(r.download){const files={tv:['MarcoTV-0.15.0.apk','下载电视安装包 · 0.15.0'],windows:['MarcoTV-Installer-1.0.0-Windows.exe','下载 Windows 安装助手'],android:['MarcoTV-Installer-1.0.0-Android.apk','下载安卓手机助手']};const [file,label]=files[r.download];const a=document.createElement('a');a.className='button';a.href=base+file;a.textContent=label;$('download').append(a);const p=document.createElement('p');p.className='download-note';p.textContent='约 8 MB · 免费 · ';const sha=document.createElement('a');sha.href=base+file+'.sha256';sha.textContent='文件校验值';p.append(sha);const source=document.createElement('a');source.href='https://github.com/Pilipala9919/MarcoTV/tree/main/installer';source.textContent='源码与说明';p.append(source);$('download').append(p);}
 if(r.docs){const a=document.createElement('a');a.href='https://github.com/Pilipala9919/MarcoTV/blob/main/docs/安装说明.md';a.textContent='查看完整安装与授权说明 ↗';$('download').append(a);}
 $('result').hidden=false;$('result').focus();$('result').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
}
$('choices').addEventListener('submit',e=>{e.preventDefault();render();});
for(const select of document.querySelectorAll('#choices select'))select.addEventListener('change',()=>{$('result').hidden=true;});
$('installError').addEventListener('change',()=>{$('installErrorHelp').textContent=installationIssue($('installError').value);});
function selectPurpose(){const home=$('purpose').value==='home';$('goalTitle').textContent=home?'让 Home 回到 Marco TV':'先看看你手边有什么';for(const id of ['device','entry']){$(id).hidden=home;document.querySelector('label[for="'+id+'"]').hidden=home;}}
$('purpose').addEventListener('change',selectPurpose);
if(location.hash==='#home'){$('purpose').value='home';$('choices').scrollIntoView({block:'start'});}
selectPurpose();
